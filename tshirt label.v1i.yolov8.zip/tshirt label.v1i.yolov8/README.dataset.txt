# tshirt label > 2024-07-29 8:19am
https://universe.roboflow.com/samiha-o2pzc/tshirt-label

Provided by a Roboflow user
License: CC BY 4.0

